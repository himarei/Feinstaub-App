import java.util.ArrayList;
import java.util.List;

public class Messstation
{
    ArrayList<Messreihe> vieleMessreihen;

    String senseBoxId;
    
    OpenSenseMap oSM;

    public Messstation(String senseBoxId_)
    {senseBoxId  = senseBoxId_;
     vieleMessreihen = new ArrayList<Messreihe>(); // Die Messstation erstellt ein Feld von Messreihen
     oSM = new OpenSenseMap(senseBoxId, this); // Die Messstation eerstellt ein neues Objekt der Klasse Open Sense Map und gibt ihm die Sensebox Id und sich selber weiter
     
     oSM.nameEinlesen();
     oSM.sensorenEinlesen();
     
     
          
   }

String wertEinlesen(String sensorTitel)
{
    String sensorId = getSensorId(sensorTitel);
    Messung messung = oSM.werteEinlesen(sensorId);
    double wert = messung.getWert();
    return String.valueOf(wert);
    
}

String zeitEinlesen(String sensorTitel)
{
    String sensorId = getSensorId(sensorTitel);
    Messung messung = oSM.werteEinlesen(sensorId);
    String zeit = messung.getErzeugtAm();
    return zeit.substring(11,16);
    
}



String messreiheWertEinlesen(String sensorTitel, int feldNummer)
{
    String sensorId = getSensorId(sensorTitel);
    ArrayList<Messung> messreihe = oSM.messreiheWerteEinlesen(sensorId);
    double wert = messreihe.get(feldNummer).getWert();
    return String.valueOf(wert);
    
}

String messreiheZeitEinlesen(String sensorTitel, int feldNummer)
{
    String sensorId = getSensorId(sensorTitel);
    ArrayList<Messung> messreihe = oSM.messreiheWerteEinlesen(sensorId);
    String zeit = messreihe.get(feldNummer).getErzeugtAm();
    return zeit.substring(11,16);
    
    
}


ArrayList<Messreihe> getVieleMessreihen()
{
  return vieleMessreihen;
}

ArrayList<Messung> getMessreihe(String sensorId_)
{
   for ( Messreihe m: vieleMessreihen)
  {
   if(m.getId().equals(sensorId_))
    {
       return m.getArrayList();
    }
  }
  return null;
}

String getSensorId(String titel_)
{
  for ( Messreihe m: vieleMessreihen)
  {
   if(m.getTitle().equals(titel_))
   {
    return m.getId();
   } 
 }
 return null;
}
}

