import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;

public class Controller extends Application {

    String ortMessstation;
    
    Messstation messstation;
    
    String senseBoxId;
    
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
    private TabPane tabPane;

    @FXML
    private Tab tabHome;

    @FXML
    private AnchorPane Home_AnzeigeFeldUhrzeit;

    @FXML
    private TextField StadtEingabeFeld;

    @FXML
    private Label AnzeigeFeldUhrzeit;

    @FXML
    private ImageView icon3;

    @FXML
    private ImageView icon1;

    @FXML
    private ImageView icon4;

    @FXML
    private ImageView icon2;

    @FXML
    private Label Home_AnzeigeFeldLuft;

    @FXML
    private Label Home_AnzeigeFeldFein;

    @FXML
    private Label Home_AnzeigeFeldTemp;

    @FXML
    private Label Celsius;

    @FXML
    private Label MikrogrammProKubikmeter;

    @FXML
    private Label GrammProqQadratmeter;

    @FXML
    private Tab tabLuftfeuchtigkeit;

    @FXML
    private ImageView HomeButton4;

    @FXML
    private ImageView icon41;

    @FXML
    private ImageView icon12;

    @FXML
    private ImageView icon411;

    @FXML
    private Label Luftfeuchtigkeit_AnzeigeFeldUhrzeit1;

    @FXML
    private Label Luftfeuchtigkeit_AnzeigeWerte1;

    @FXML
    private Label Luftfeuchtigkeit_AnzeigeFeldUhrzeit2;

    @FXML
    private Label Luftfeuchtigkeit_AnzeigeWerte2;

    @FXML
    private Label Luftfeuchtigkeit_AnzeigeFeldUhrzeit3;

    @FXML
    private Label Luftfeuchtigkeit_AnzeigeWerte3;

    @FXML
    private Label Luftfeuchtigkeit_AnzeigeFeldUhrzeit4;

    @FXML
    private Label Luftfeuchtigkeit_AnzeigeWerte4;

    @FXML
    private Tab tabTemperatur;

    @FXML
    private ImageView HomeButton2;

    @FXML
    private ImageView icon21;

    @FXML
    private ImageView icon121;

    @FXML
    private Label Temperatur_AnzeigeFeldUhrzeit4;

    @FXML
    private Label Temperatur_AnzeigeWerte4;

    @FXML
    private Label Temperatur_AnzeigeFeldUhrzeit3;

    @FXML
    private Label Temperatur_AnzeigeWerte3;

    @FXML
    private Label Temperatur_AnzeigeFeldUhrzeit1;

    @FXML
    private Label Temperatur_AnzeigeWerte1;

    @FXML
    private Label Temperatur_AnzeigeFeldUhrzeit2;

    @FXML
    private Label Temperatur_AnzeigeWerte2;

    @FXML
    private ImageView icon211;

    @FXML
    private Tab tabCo2Gehalt;

    @FXML
    private ImageView HomeButton3;

    @FXML
    private ImageView icon31;

    @FXML
    private ImageView icon1211;

    @FXML
    private Label Kohlenstoffdioxid_AnzeigeFeldUhrzeit4;

    @FXML
    private Label CO2Gehalt_AnzeigeWerte4;

    @FXML
    private Label Kohlenstoffdioxid_AnzeigeFeldUhrzeit3;

    @FXML
    private Label CO2Gehalt_AnzeigeWerte3;

    @FXML
    private Label Kohlenstoffdioxid_AnzeigeFeldUhrzeit2;

    @FXML
    private Label CO2Gehalt_AnzeigeWerte2;

    @FXML
    private Label Kohlenstoffdioxid_AnzeigeFeldUhrzeit1;

    @FXML
    private Label CO2Gehalt_AnzeigeWerte1;

    @FXML
    private ImageView icon311;
    
   
    
    public Controller()
    {
        senseBoxId = "60df298616d878001ba3116f";
        messstation = new Messstation(senseBoxId);
        ortMessstation = "Dachau";
        
        
        
        
        
    }
    
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Darstellung als fxml-Datei
        FXMLLoader loader = new FXMLLoader(getClass().getResource("layout3.fxml"));
        Parent root = loader.load();
        // Fenster erstellen und anzeigen
        Scene scene = new Scene(root);
        //scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
        
    }
    
    public static void main(String[] args) {
        launch(args);
    }





    

    @FXML
    void HomeButton2geklickt(MouseEvent event) {
        tabPane.getSelectionModel().select(tabHome);

    }

    @FXML
    void HomeButton3geklickt(MouseEvent event) {
        tabPane.getSelectionModel().select(tabHome);

    }

    @FXML
    void HomeButton4geklickt(MouseEvent event) {
        tabPane.getSelectionModel().select(tabHome);

    }

    @FXML
    void HomeButtonGeklickt(MouseEvent event) {
        tabPane.getSelectionModel().select(tabHome);

    }
    
    
    
    @FXML
    void LuftfeuchtGeklickt(MouseEvent event) {
        tabPane.getSelectionModel().select(tabLuftfeuchtigkeit);

    }

    @FXML
    void TempGeklickt(MouseEvent event) {
        tabPane.getSelectionModel().select(tabTemperatur);

    }
    
        @FXML
    void CO2Geklickt(MouseEvent event) {
        tabPane.getSelectionModel().select(tabCo2Gehalt);

    }

    @FXML
    void initialize() {
        assert tabPane != null : "fx:id=\"tabPane\" was not injected: check your FXML file 'layout.fxml'.";
        assert tabHome != null : "fx:id=\"tabHome\" was not injected: check your FXML file 'layout.fxml'.";
        assert Home_AnzeigeFeldUhrzeit != null : "fx:id=\"Home_AnzeigeFeldUhrzeit\" was not injected: check your FXML file 'layout.fxml'.";
        assert StadtEingabeFeld != null : "fx:id=\"StadtEingabeFeld\" was not injected: check your FXML file 'layout.fxml'.";
        assert AnzeigeFeldUhrzeit != null : "fx:id=\"AnzeigeFeldUhrzeit\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon3 != null : "fx:id=\"icon3\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon1 != null : "fx:id=\"icon1\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon4 != null : "fx:id=\"icon4\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon2 != null : "fx:id=\"icon2\" was not injected: check your FXML file 'layout.fxml'.";
        assert Home_AnzeigeFeldLuft != null : "fx:id=\"Home_AnzeigeFeldLuft\" was not injected: check your FXML file 'layout.fxml'.";
        assert Home_AnzeigeFeldFein != null : "fx:id=\"Home_AnzeigeFeldFein\" was not injected: check your FXML file 'layout.fxml'.";
        assert Home_AnzeigeFeldTemp != null : "fx:id=\"Home_AnzeigeFeldTemp\" was not injected: check your FXML file 'layout.fxml'.";
        assert Celsius != null : "fx:id=\"Celsius\" was not injected: check your FXML file 'layout.fxml'.";
        assert MikrogrammProKubikmeter != null : "fx:id=\"MikrogrammProKubikmeter\" was not injected: check your FXML file 'layout.fxml'.";
        assert GrammProqQadratmeter != null : "fx:id=\"GrammProqQadratmeter\" was not injected: check your FXML file 'layout.fxml'.";
        assert tabLuftfeuchtigkeit != null : "fx:id=\"tabLuftfeuchtigkeit\" was not injected: check your FXML file 'layout.fxml'.";
        assert HomeButton4 != null : "fx:id=\"HomeButton4\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon41 != null : "fx:id=\"icon41\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon12 != null : "fx:id=\"icon12\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon411 != null : "fx:id=\"icon411\" was not injected: check your FXML file 'layout.fxml'.";
        assert Luftfeuchtigkeit_AnzeigeFeldUhrzeit1 != null : "fx:id=\"Luftfeuchtigkeit_AnzeigeFeldUhrzeit1\" was not injected: check your FXML file 'layout.fxml'.";
        assert Luftfeuchtigkeit_AnzeigeWerte1 != null : "fx:id=\"Luftfeuchtigkeit_AnzeigeWerte1\" was not injected: check your FXML file 'layout.fxml'.";
        assert Luftfeuchtigkeit_AnzeigeFeldUhrzeit2 != null : "fx:id=\"Luftfeuchtigkeit_AnzeigeFeldUhrzeit2\" was not injected: check your FXML file 'layout.fxml'.";
        assert Luftfeuchtigkeit_AnzeigeWerte2 != null : "fx:id=\"Luftfeuchtigkeit_AnzeigeWerte2\" was not injected: check your FXML file 'layout.fxml'.";
        assert Luftfeuchtigkeit_AnzeigeFeldUhrzeit3 != null : "fx:id=\"Luftfeuchtigkeit_AnzeigeFeldUhrzeit3\" was not injected: check your FXML file 'layout.fxml'.";
        assert Luftfeuchtigkeit_AnzeigeWerte3 != null : "fx:id=\"Luftfeuchtigkeit_AnzeigeWerte3\" was not injected: check your FXML file 'layout.fxml'.";
        assert Luftfeuchtigkeit_AnzeigeFeldUhrzeit4 != null : "fx:id=\"Luftfeuchtigkeit_AnzeigeFeldUhrzeit4\" was not injected: check your FXML file 'layout.fxml'.";
        assert Luftfeuchtigkeit_AnzeigeWerte4 != null : "fx:id=\"Luftfeuchtigkeit_AnzeigeWerte4\" was not injected: check your FXML file 'layout.fxml'.";
        assert tabTemperatur != null : "fx:id=\"tabTemperatur\" was not injected: check your FXML file 'layout.fxml'.";
        assert HomeButton2 != null : "fx:id=\"HomeButton2\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon21 != null : "fx:id=\"icon21\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon121 != null : "fx:id=\"icon121\" was not injected: check your FXML file 'layout.fxml'.";
        assert Temperatur_AnzeigeFeldUhrzeit4 != null : "fx:id=\"Temperatur_AnzeigeFeldUhrzeit4\" was not injected: check your FXML file 'layout.fxml'.";
        assert Temperatur_AnzeigeWerte4 != null : "fx:id=\"Temperatur_AnzeigeWerte4\" was not injected: check your FXML file 'layout.fxml'.";
        assert Temperatur_AnzeigeFeldUhrzeit3 != null : "fx:id=\"Temperatur_AnzeigeFeldUhrzeit3\" was not injected: check your FXML file 'layout.fxml'.";
        assert Temperatur_AnzeigeWerte3 != null : "fx:id=\"Temperatur_AnzeigeWerte3\" was not injected: check your FXML file 'layout.fxml'.";
        assert Temperatur_AnzeigeFeldUhrzeit1 != null : "fx:id=\"Temperatur_AnzeigeFeldUhrzeit1\" was not injected: check your FXML file 'layout.fxml'.";
        assert Temperatur_AnzeigeWerte1 != null : "fx:id=\"Temperatur_AnzeigeWerte1\" was not injected: check your FXML file 'layout.fxml'.";
        assert Temperatur_AnzeigeFeldUhrzeit2 != null : "fx:id=\"Temperatur_AnzeigeFeldUhrzeit2\" was not injected: check your FXML file 'layout.fxml'.";
        assert Temperatur_AnzeigeWerte2 != null : "fx:id=\"Temperatur_AnzeigeWerte2\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon211 != null : "fx:id=\"icon211\" was not injected: check your FXML file 'layout.fxml'.";
        assert tabCo2Gehalt != null : "fx:id=\"tabCo2Gehalt\" was not injected: check your FXML file 'layout.fxml'.";
        assert HomeButton3 != null : "fx:id=\"HomeButton3\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon31 != null : "fx:id=\"icon31\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon1211 != null : "fx:id=\"icon1211\" was not injected: check your FXML file 'layout.fxml'.";
        assert Kohlenstoffdioxid_AnzeigeFeldUhrzeit4 != null : "fx:id=\"Kohlenstoffdioxid_AnzeigeFeldUhrzeit4\" was not injected: check your FXML file 'layout.fxml'.";
        assert CO2Gehalt_AnzeigeWerte4 != null : "fx:id=\"CO2Gehalt_AnzeigeWerte4\" was not injected: check your FXML file 'layout.fxml'.";
        assert Kohlenstoffdioxid_AnzeigeFeldUhrzeit3 != null : "fx:id=\"Kohlenstoffdioxid_AnzeigeFeldUhrzeit3\" was not injected: check your FXML file 'layout.fxml'.";
        assert CO2Gehalt_AnzeigeWerte3 != null : "fx:id=\"CO2Gehalt_AnzeigeWerte3\" was not injected: check your FXML file 'layout.fxml'.";
        assert Kohlenstoffdioxid_AnzeigeFeldUhrzeit2 != null : "fx:id=\"Kohlenstoffdioxid_AnzeigeFeldUhrzeit2\" was not injected: check your FXML file 'layout.fxml'.";
        assert CO2Gehalt_AnzeigeWerte2 != null : "fx:id=\"CO2Gehalt_AnzeigeWerte2\" was not injected: check your FXML file 'layout.fxml'.";
        assert Kohlenstoffdioxid_AnzeigeFeldUhrzeit1 != null : "fx:id=\"Kohlenstoffdioxid_AnzeigeFeldUhrzeit1\" was not injected: check your FXML file 'layout.fxml'.";
        assert CO2Gehalt_AnzeigeWerte1 != null : "fx:id=\"CO2Gehalt_AnzeigeWerte1\" was not injected: check your FXML file 'layout.fxml'.";
        assert icon311 != null : "fx:id=\"icon311\" was not injected: check your FXML file 'layout.fxml'.";
        
        StadtEingabeFeld.setText(ortMessstation);
        
        
        AnzeigeFeldUhrzeit.setText(messstation.zeitEinlesen("Lufttemperatur"));
        Home_AnzeigeFeldTemp.setText(messstation.wertEinlesen("Lufttemperatur"));
        Home_AnzeigeFeldFein.setText(messstation.wertEinlesen("CO₂"));
        Home_AnzeigeFeldLuft.setText(messstation.wertEinlesen("Luftfeuchte"));
        
        
        
        Temperatur_AnzeigeWerte1.setText(messstation.messreiheWertEinlesen("Lufttemperatur", 0));
        Temperatur_AnzeigeWerte2.setText(messstation.messreiheWertEinlesen("Lufttemperatur", 1));
        Temperatur_AnzeigeWerte3.setText(messstation.messreiheWertEinlesen("Lufttemperatur", 2));
        Temperatur_AnzeigeWerte4.setText(messstation.messreiheWertEinlesen("Lufttemperatur", 3));
        
        Temperatur_AnzeigeFeldUhrzeit1.setText(messstation.messreiheZeitEinlesen("Lufttemperatur", 0));
        Temperatur_AnzeigeFeldUhrzeit2.setText(messstation.messreiheZeitEinlesen("Lufttemperatur", 1));
        Temperatur_AnzeigeFeldUhrzeit3.setText(messstation.messreiheZeitEinlesen("Lufttemperatur", 2));
        Temperatur_AnzeigeFeldUhrzeit4.setText(messstation.messreiheZeitEinlesen("Lufttemperatur", 3));
        
        
        Luftfeuchtigkeit_AnzeigeWerte1.setText(messstation.messreiheWertEinlesen("Luftfeuchte", 0));
        Luftfeuchtigkeit_AnzeigeWerte2.setText(messstation.messreiheWertEinlesen("Luftfeuchte", 1));
        Luftfeuchtigkeit_AnzeigeWerte3.setText(messstation.messreiheWertEinlesen("Luftfeuchte", 2));
        Luftfeuchtigkeit_AnzeigeWerte4.setText(messstation.messreiheWertEinlesen("Luftfeuchte", 3));
        
        Luftfeuchtigkeit_AnzeigeFeldUhrzeit1.setText(messstation.messreiheZeitEinlesen("Luftfeuchte", 0));
        Luftfeuchtigkeit_AnzeigeFeldUhrzeit2.setText(messstation.messreiheZeitEinlesen("Luftfeuchte", 1));
        Luftfeuchtigkeit_AnzeigeFeldUhrzeit3.setText(messstation.messreiheZeitEinlesen("Luftfeuchte", 2));
        Luftfeuchtigkeit_AnzeigeFeldUhrzeit4.setText(messstation.messreiheZeitEinlesen("Luftfeuchte", 3));
        
        
        
        CO2Gehalt_AnzeigeWerte1.setText(messstation.messreiheWertEinlesen("CO₂", 0));
        CO2Gehalt_AnzeigeWerte2.setText(messstation.messreiheWertEinlesen("CO₂", 1));
        CO2Gehalt_AnzeigeWerte3.setText(messstation.messreiheWertEinlesen("CO₂", 2));
        CO2Gehalt_AnzeigeWerte4.setText(messstation.messreiheWertEinlesen("CO₂", 3));
        
        Kohlenstoffdioxid_AnzeigeFeldUhrzeit1.setText(messstation.messreiheZeitEinlesen("CO₂", 0));
        Kohlenstoffdioxid_AnzeigeFeldUhrzeit2.setText(messstation.messreiheZeitEinlesen("CO₂", 1));
        Kohlenstoffdioxid_AnzeigeFeldUhrzeit3.setText(messstation.messreiheZeitEinlesen("CO₂", 2));
        Kohlenstoffdioxid_AnzeigeFeldUhrzeit4.setText(messstation.messreiheZeitEinlesen("CO₂", 3));
    }
 }

    
    
  
        
    
    



