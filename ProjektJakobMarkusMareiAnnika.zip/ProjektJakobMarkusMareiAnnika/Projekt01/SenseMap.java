import java.util.*;

public interface SenseMap
{
    public String nameEinlesen();
    public ArrayList<Messreihe> sensorenEinlesen();
    public Messung werteEinlesen(String sensorId);
    public ArrayList<Messung> messreiheWerteEinlesen(String sensorId);
    
}
