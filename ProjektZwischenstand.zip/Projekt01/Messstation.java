import java.util.ArrayList;
import java.util.List;

public class Messstation
{
    ArrayList<Messreihe> vieleMessreihen;

    String senseBoxId;

    public Messstation(String senseBoxId_)
    { senseBoxId  = senseBoxId_;
        vieleMessreihen = new ArrayList<Messreihe>();
        OpenSenseMap oSM = new OpenSenseMap(senseBoxId, this);
        oSM.nameEinlesen();
        oSM.sensorenEinlesen();
        //oSM.werteEinlesen(getSensorId("Luftdruck"));
        //oSM.werteEinlesen(getSensorId("Temperatur"));
        //oSM.messreiheWerteEinlesen(getSensorId("Temperatur"));
        oSM.messreiheWerteEinlesen(getSensorId("Luftdruck"));
}

ArrayList<Messreihe> getVieleMessreihen()
{
return vieleMessreihen;
}

ArrayList<Messung> getMessreihe(String sensorId_)
{
for ( Messreihe m: vieleMessreihen)
{
if(m.getId().equals(sensorId_))
{
return m.getArrayList();
}
}
return null;
}

String getSensorId(String titel_)
{
for ( Messreihe m: vieleMessreihen)
{
if(m.getTitle().equals(titel_))
{
return m.getId();
}
}
return null;
}
}

