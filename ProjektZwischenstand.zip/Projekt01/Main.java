import java.util.ArrayList;
import java.util.List;
public class Main
{
    
    Messstation messstation;
    
    String senseBoxId;
    
    public Main()
    {
        senseBoxId = "606dabb74393eb001ca6a781";
        
        messstation = new Messstation(senseBoxId);
        
        
        
    }
    
}