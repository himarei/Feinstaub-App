
public class Messung
{
    
   double wert;
   String erzeugtAm;
    
    public Messung(double wert_ ,String erzeugtAm_)
    {
        wert= wert_;
        erzeugtAm=erzeugtAm_;
       
    }
    
    double getWert()
    {
        return wert;
    }
    
    String getErzeugtAm()
    {
        return erzeugtAm;
    }
   
}