import java.util.ArrayList;
import java.util.List;
public class Main
{
    
    Messstation messstation;
    
    String senseBoxId;
    
    public Main()
    {
        senseBoxId = "60df298616d878001ba3116f";
        messstation = new Messstation(senseBoxId);
        
        
        
    }
    
}